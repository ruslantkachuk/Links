// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.RedBearService;

import android.os.Binder;

// Referenced classes of package com.redbear.RedBearService:
//            RedBearService

public class this._cls0 extends Binder
{

    final RedBearService this$0;

    public RedBearService getService()
    {
        return RedBearService.this;
    }

    public ()
    {
        this$0 = RedBearService.this;
        super();
    }
}
