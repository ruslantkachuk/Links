// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


// Referenced classes of package com.redbear.redbearbleclient:
//            R

public static final class 
{

    public static final int activity_main_page = 0x7f030000;
    public static final int activity_standardview = 0x7f030001;
    public static final int activity_standardview_pins = 0x7f030002;
    public static final int activity_standardview_pins_ex = 0x7f030003;
    public static final int main_page_layout = 0x7f030004;
    public static final int main_page_listview_item = 0x7f030005;
    public static final int refreshlist_head = 0x7f030006;
    public static final int standardview_item = 0x7f030007;
    public static final int standardview_item_ex = 0x7f030008;

    public ()
    {
    }
}
