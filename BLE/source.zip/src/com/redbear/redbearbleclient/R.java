// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


public final class R
{
    public static final class anim
    {

        public static final int slide_in_from_bottom = 0x7f040000;
        public static final int slide_in_from_left = 0x7f040001;
        public static final int slide_in_from_right = 0x7f040002;
        public static final int slide_in_from_top = 0x7f040003;
        public static final int slide_out_to_bottom = 0x7f040004;
        public static final int slide_out_to_left = 0x7f040005;
        public static final int slide_out_to_right = 0x7f040006;
        public static final int slide_out_to_top = 0x7f040007;

        public anim()
        {
        }
    }

    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class color
    {

        public static final int black = 0x7f050003;
        public static final int blue = 0x7f050004;
        public static final int gold = 0x7f050002;
        public static final int transparent = 0x7f050001;
        public static final int white = 0x7f050000;

        public color()
        {
        }
    }

    public static final class drawable
    {

        public static final int add_icon = 0x7f020000;
        public static final int arrow = 0x7f020001;
        public static final int button_clicked = 0x7f020002;
        public static final int button_selector = 0x7f020003;
        public static final int ic_launcher = 0x7f020004;
        public static final int mainpage_listview_item_bg = 0x7f020005;
        public static final int remove_icon = 0x7f020006;
        public static final int right_row = 0x7f020007;
        public static final int setting_icon = 0x7f020008;
        public static final int splash = 0x7f020009;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int big_name = 0x7f09000f;
        public static final int btn_send = 0x7f090004;
        public static final int container = 0x7f090000;
        public static final int detail = 0x7f09000d;
        public static final int edit_input = 0x7f090006;
        public static final int edit_output = 0x7f090005;
        public static final int head_arrowImageView = 0x7f090016;
        public static final int head_contentLayout = 0x7f090014;
        public static final int head_lastUpdatedTextView = 0x7f090019;
        public static final int head_progressBar = 0x7f090017;
        public static final int head_tipsTextView = 0x7f090018;
        public static final int headview_area = 0x7f090001;
        public static final int io_list = 0x7f090008;
        public static final int io_mode = 0x7f09001b;
        public static final int loading = 0x7f090015;
        public static final int local_name = 0x7f090013;
        public static final int menu_disconnect = 0x7f090020;
        public static final int menu_settings = 0x7f09001f;
        public static final int name = 0x7f090012;
        public static final int number = 0x7f09001d;
        public static final int pageloading = 0x7f09000c;
        public static final int pin = 0x7f09001a;
        public static final int pin_loading = 0x7f090007;
        public static final int pins_list = 0x7f090009;
        public static final int progressbar = 0x7f09001e;
        public static final int refresh_listview = 0x7f09000b;
        public static final int scan_result = 0x7f09000a;
        public static final int service = 0x7f090011;
        public static final int switcher = 0x7f09001c;
        public static final int text_devicename = 0x7f090002;
        public static final int text_info = 0x7f09000e;
        public static final int text_rssi = 0x7f090003;
        public static final int uuid = 0x7f090010;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int activity_main_page = 0x7f030000;
        public static final int activity_standardview = 0x7f030001;
        public static final int activity_standardview_pins = 0x7f030002;
        public static final int activity_standardview_pins_ex = 0x7f030003;
        public static final int main_page_layout = 0x7f030004;
        public static final int main_page_listview_item = 0x7f030005;
        public static final int refreshlist_head = 0x7f030006;
        public static final int standardview_item = 0x7f030007;
        public static final int standardview_item_ex = 0x7f030008;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int activity_main_page = 0x7f080000;
        public static final int activity_standardview = 0x7f080001;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int addpage_name = 0x7f060002;
        public static final int app_name = 0x7f060000;
        public static final int bluetooth_not_enable = 0x7f060014;
        public static final int hello_world = 0x7f060007;
        public static final int input_label = 0x7f060008;
        public static final int label_no_devices = 0x7f060013;
        public static final int menu_add = 0x7f06000c;
        public static final int menu_disconnect = 0x7f06000d;
        public static final int menu_settings = 0x7f06000b;
        public static final int ok_title = 0x7f060016;
        public static final int output_Label = 0x7f06000a;
        public static final int pulltorefresh_lasttime_label = 0x7f060012;
        public static final int pulltorefresh_lasttimeupdate_label = 0x7f06000f;
        public static final int pulltorefresh_pullltorefresh_label = 0x7f06000e;
        public static final int pulltorefresh_refreshing_label = 0x7f060010;
        public static final int pulltorefresh_releasetorefresh_label = 0x7f060011;
        public static final int send_label = 0x7f060009;
        public static final int settingpage_name = 0x7f060001;
        public static final int standardview_name = 0x7f060003;
        public static final int tip_dialog_title = 0x7f060015;
        public static final int title_section1 = 0x7f060006;
        public static final int title_section2 = 0x7f060005;
        public static final int title_section3 = 0x7f060004;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f070000;
        public static final int AppTheme = 0x7f070001;

        public style()
        {
        }
    }


    public R()
    {
    }
}
