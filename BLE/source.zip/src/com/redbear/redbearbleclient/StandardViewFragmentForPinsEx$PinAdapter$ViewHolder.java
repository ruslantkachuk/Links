// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;

import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

// Referenced classes of package com.redbear.redbearbleclient:
//            StandardViewFragmentForPinsEx

class this._cls1
{

    TextView analog;
    Switch digitol;
    Button mode;
    TextView pin;
    SeekBar servo;
    final this._cls1 this$1;

    ()
    {
        this$1 = this._cls1.this;
        super();
    }
}
