// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient.view.listviewanimation;

import com.nineoldandroids.animation.Animator;

// Referenced classes of package com.redbear.redbearbleclient.view.listviewanimation:
//            AnimationAdapter

private class animator
{

    public Animator animator;
    public int position;
    final AnimationAdapter this$0;

    public (int i, Animator animator1)
    {
        this$0 = AnimationAdapter.this;
        super();
        position = i;
        animator = animator1;
    }
}
