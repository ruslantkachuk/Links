// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


// Referenced classes of package com.redbear.redbearbleclient:
//            R

public static final class 
{

    public static final int big_name = 0x7f09000f;
    public static final int btn_send = 0x7f090004;
    public static final int container = 0x7f090000;
    public static final int detail = 0x7f09000d;
    public static final int edit_input = 0x7f090006;
    public static final int edit_output = 0x7f090005;
    public static final int head_arrowImageView = 0x7f090016;
    public static final int head_contentLayout = 0x7f090014;
    public static final int head_lastUpdatedTextView = 0x7f090019;
    public static final int head_progressBar = 0x7f090017;
    public static final int head_tipsTextView = 0x7f090018;
    public static final int headview_area = 0x7f090001;
    public static final int io_list = 0x7f090008;
    public static final int io_mode = 0x7f09001b;
    public static final int loading = 0x7f090015;
    public static final int local_name = 0x7f090013;
    public static final int menu_disconnect = 0x7f090020;
    public static final int menu_settings = 0x7f09001f;
    public static final int name = 0x7f090012;
    public static final int number = 0x7f09001d;
    public static final int pageloading = 0x7f09000c;
    public static final int pin = 0x7f09001a;
    public static final int pin_loading = 0x7f090007;
    public static final int pins_list = 0x7f090009;
    public static final int progressbar = 0x7f09001e;
    public static final int refresh_listview = 0x7f09000b;
    public static final int scan_result = 0x7f09000a;
    public static final int service = 0x7f090011;
    public static final int switcher = 0x7f09001c;
    public static final int text_devicename = 0x7f090002;
    public static final int text_info = 0x7f09000e;
    public static final int text_rssi = 0x7f090003;
    public static final int uuid = 0x7f090010;

    public ()
    {
    }
}
