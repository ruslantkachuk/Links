// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


// Referenced classes of package com.redbear.redbearbleclient:
//            R

public static final class 
{

    public static final int add_icon = 0x7f020000;
    public static final int arrow = 0x7f020001;
    public static final int button_clicked = 0x7f020002;
    public static final int button_selector = 0x7f020003;
    public static final int ic_launcher = 0x7f020004;
    public static final int mainpage_listview_item_bg = 0x7f020005;
    public static final int remove_icon = 0x7f020006;
    public static final int right_row = 0x7f020007;
    public static final int setting_icon = 0x7f020008;
    public static final int splash = 0x7f020009;

    public ()
    {
    }
}
