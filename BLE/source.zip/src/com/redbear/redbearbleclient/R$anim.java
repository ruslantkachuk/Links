// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


// Referenced classes of package com.redbear.redbearbleclient:
//            R

public static final class 
{

    public static final int slide_in_from_bottom = 0x7f040000;
    public static final int slide_in_from_left = 0x7f040001;
    public static final int slide_in_from_right = 0x7f040002;
    public static final int slide_in_from_top = 0x7f040003;
    public static final int slide_out_to_bottom = 0x7f040004;
    public static final int slide_out_to_left = 0x7f040005;
    public static final int slide_out_to_right = 0x7f040006;
    public static final int slide_out_to_top = 0x7f040007;

    public ()
    {
    }
}
