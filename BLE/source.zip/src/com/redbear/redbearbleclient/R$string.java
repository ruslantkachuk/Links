// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.redbear.redbearbleclient;


// Referenced classes of package com.redbear.redbearbleclient:
//            R

public static final class 
{

    public static final int addpage_name = 0x7f060002;
    public static final int app_name = 0x7f060000;
    public static final int bluetooth_not_enable = 0x7f060014;
    public static final int hello_world = 0x7f060007;
    public static final int input_label = 0x7f060008;
    public static final int label_no_devices = 0x7f060013;
    public static final int menu_add = 0x7f06000c;
    public static final int menu_disconnect = 0x7f06000d;
    public static final int menu_settings = 0x7f06000b;
    public static final int ok_title = 0x7f060016;
    public static final int output_Label = 0x7f06000a;
    public static final int pulltorefresh_lasttime_label = 0x7f060012;
    public static final int pulltorefresh_lasttimeupdate_label = 0x7f06000f;
    public static final int pulltorefresh_pullltorefresh_label = 0x7f06000e;
    public static final int pulltorefresh_refreshing_label = 0x7f060010;
    public static final int pulltorefresh_releasetorefresh_label = 0x7f060011;
    public static final int send_label = 0x7f060009;
    public static final int settingpage_name = 0x7f060001;
    public static final int standardview_name = 0x7f060003;
    public static final int tip_dialog_title = 0x7f060015;
    public static final int title_section1 = 0x7f060006;
    public static final int title_section2 = 0x7f060005;
    public static final int title_section3 = 0x7f060004;

    public ()
    {
    }
}
