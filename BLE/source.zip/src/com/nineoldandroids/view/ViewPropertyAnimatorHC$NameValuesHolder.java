// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.nineoldandroids.view;


// Referenced classes of package com.nineoldandroids.view:
//            ViewPropertyAnimatorHC

private static class mDeltaValue
{

    float mDeltaValue;
    float mFromValue;
    int mNameConstant;

    (int i, float f, float f1)
    {
        mNameConstant = i;
        mFromValue = f;
        mDeltaValue = f1;
    }
}
