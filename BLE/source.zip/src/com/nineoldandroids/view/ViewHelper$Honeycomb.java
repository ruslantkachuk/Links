// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.nineoldandroids.view;

import android.view.View;

// Referenced classes of package com.nineoldandroids.view:
//            ViewHelper

private static final class 
{

    static float getAlpha(View view)
    {
        return view.getAlpha();
    }

    static float getPivotX(View view)
    {
        return view.getPivotX();
    }

    static float getPivotY(View view)
    {
        return view.getPivotY();
    }

    static float getRotation(View view)
    {
        return view.getRotation();
    }

    static float getRotationX(View view)
    {
        return view.getRotationX();
    }

    static float getRotationY(View view)
    {
        return view.getRotationY();
    }

    static float getScaleX(View view)
    {
        return view.getScaleX();
    }

    static float getScaleY(View view)
    {
        return view.getScaleY();
    }

    static float getScrollX(View view)
    {
        return (float)view.getScrollX();
    }

    static float getScrollY(View view)
    {
        return (float)view.getScrollY();
    }

    static float getTranslationX(View view)
    {
        return view.getTranslationX();
    }

    static float getTranslationY(View view)
    {
        return view.getTranslationY();
    }

    static float getX(View view)
    {
        return view.getX();
    }

    static float getY(View view)
    {
        return view.getY();
    }

    static void setAlpha(View view, float f)
    {
        view.setAlpha(f);
    }

    static void setPivotX(View view, float f)
    {
        view.setPivotX(f);
    }

    static void setPivotY(View view, float f)
    {
        view.setPivotY(f);
    }

    static void setRotation(View view, float f)
    {
        view.setRotation(f);
    }

    static void setRotationX(View view, float f)
    {
        view.setRotationX(f);
    }

    static void setRotationY(View view, float f)
    {
        view.setRotationY(f);
    }

    static void setScaleX(View view, float f)
    {
        view.setScaleX(f);
    }

    static void setScaleY(View view, float f)
    {
        view.setScaleY(f);
    }

    static void setScrollX(View view, int i)
    {
        view.setScrollX(i);
    }

    static void setScrollY(View view, int i)
    {
        view.setScrollY(i);
    }

    static void setTranslationX(View view, float f)
    {
        view.setTranslationX(f);
    }

    static void setTranslationY(View view, float f)
    {
        view.setTranslationY(f);
    }

    static void setX(View view, float f)
    {
        view.setX(f);
    }

    static void setY(View view, float f)
    {
        view.setY(f);
    }

    private ()
    {
    }
}
