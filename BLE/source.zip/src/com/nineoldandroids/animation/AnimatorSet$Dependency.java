// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.nineoldandroids.animation;


// Referenced classes of package com.nineoldandroids.animation:
//            AnimatorSet

private static class rule
{

    static final int AFTER = 1;
    static final int WITH;
    public rule node;
    public int rule;

    public ( , int i)
    {
        node = ;
        rule = i;
    }
}
