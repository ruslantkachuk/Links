// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.View;

public class ViewCompatJellybeanMr1
{

    public ViewCompatJellybeanMr1()
    {
    }

    public static int getLabelFor(View view)
    {
        return view.getLabelFor();
    }

    public static void setLabelFor(View view, int i)
    {
        view.setLabelFor(i);
    }
}
