// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

// Referenced classes of package android.support.v4.widget:
//            EdgeEffectCompat

static class 
    implements 
{

    public boolean draw(Object obj, Canvas canvas)
    {
        return false;
    }

    public void finish(Object obj)
    {
    }

    public boolean isFinished(Object obj)
    {
        return true;
    }

    public Object newEdgeEffect(Context context)
    {
        return null;
    }

    public boolean onAbsorb(Object obj, int i)
    {
        return false;
    }

    public boolean onPull(Object obj, float f)
    {
        return false;
    }

    public boolean onRelease(Object obj)
    {
        return false;
    }

    public void setSize(Object obj, int i, int j)
    {
    }

    ()
    {
    }
}
